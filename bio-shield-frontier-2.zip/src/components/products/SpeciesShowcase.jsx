import React from 'react';
import { motion } from 'framer-motion';
import { SPECIES_ILLUSTRATIONS } from '@/lib/illustrationData';
import { useLang } from '@/lib/i18n';

export default function SpeciesShowcase() {
  const { lang } = useLang();
  
  const getSpeciesLabel = (key) => {
    const labels = {
      Bovine: lang === 'EN' ? 'Cattle' : lang === 'AZ' ? 'Qaramal' : 'КРС',
      Porcine: lang === 'EN' ? 'Swine' : lang === 'AZ' ? 'Donuz' : 'Свиньи',
      Ovine: lang === 'EN' ? 'Sheep' : lang === 'AZ' ? 'Qoyun' : 'Овцы',
      Equine: lang === 'EN' ? 'Horses' : lang === 'AZ' ? 'Atlar' : 'Лошади',
      Poultry: lang === 'EN' ? 'Poultry' : lang === 'AZ' ? 'Quşlar' : 'Птица',
      Caprine: lang === 'EN' ? 'Goats' : lang === 'AZ' ? 'Keçilər' : 'Козы',
    };
    return labels[key] || key;
  };

  const species = [
    { key: 'Bovine' },
    { key: 'Porcine' },
    { key: 'Ovine' },
    { key: 'Equine' },
    { key: 'Poultry' },
    { key: 'Caprine' },
  ];

  return (
    <div className="grid grid-cols-3 md:grid-cols-6 gap-4 p-6 bg-gradient-to-r from-primary/5 via-transparent to-primary/5 rounded-2xl border border-primary/10 mb-8">
      {species.map((sp, i) => (
        <motion.div
          key={sp.key}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.1 }}
          className="flex flex-col items-center gap-2"
        >
          <div className="relative w-20 h-20 rounded-lg overflow-hidden border border-primary/20 bg-white/5 hover:border-primary/40 transition-colors">
            <img
              src={SPECIES_ILLUSTRATIONS[sp.key]}
              alt={getSpeciesLabel(sp.key)}
              className="w-full h-full object-cover"
            />
          </div>
          <p className="text-xs font-orbitron font-bold text-foreground text-center">{getSpeciesLabel(sp.key)}</p>
        </motion.div>
      ))}
    </div>
  );
}