import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Zap, Shield, Heart } from 'lucide-react';
import { useLang } from '@/lib/i18n';
import { getCategoryLabel, getProductName } from '@/lib/productCatalogI18n';
import { getProductDescription } from '@/lib/productSpecificationsI18n';
import { getSpeciesLabel, SPECIES_EMOJI } from '@/lib/speciesTranslationsI18n';
import { SPECIES_ILLUSTRATIONS, HEALTH_ILLUSTRATIONS } from '@/lib/illustrationData';

const CATEGORY_COLORS = {
  'Anti-inflammatory/Analgesic': { color: '#f87171', emoji: '🔥', glow: 'rgba(248,113,113,0.3)' },
  'Anti-parasitic': { color: '#34d399', emoji: '🦠', glow: 'rgba(52,211,153,0.3)' },
  'Antibiotics': { color: '#38bdf8', emoji: '💊', glow: 'rgba(56,189,248,0.3)' },
  'Antiviral': { color: '#a78bfa', emoji: '🛡️', glow: 'rgba(167,139,250,0.3)' },
  'Nutritional supplement': { color: '#fbbf24', emoji: '🥗', glow: 'rgba(251,191,36,0.3)' },
  'Respiratory system': { color: '#06b6d4', emoji: '💨', glow: 'rgba(6,182,212,0.3)' },
  'Cardiovascular': { color: '#ec4899', emoji: '❤️', glow: 'rgba(236,72,153,0.3)' },
  'Digestive/Gastrointestinal': { color: '#f59e0b', emoji: '🍽️', glow: 'rgba(245,158,11,0.3)' },
  'Immune support': { color: '#10b981', emoji: '⚔️', glow: 'rgba(16,185,129,0.3)' },
};



export default function ProductCard({ product }) {
   const { lang, t } = useLang();
   const [expanded, setExpanded] = useState(false);
   const [isFavorite, setIsFavorite] = useState(false);
   const catInfo = CATEGORY_COLORS[product.category] || { color: '#6b7280', emoji: '💊', glow: 'rgba(107,114,128,0.3)' };
   const speciesImage = product.species?.[0] ? SPECIES_ILLUSTRATIONS[product.species[0]] : null;

  useEffect(() => {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    setIsFavorite(favorites.includes(product.id));
  }, [product.id]);

  const handleFavorite = (e) => {
    e.stopPropagation();
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    if (isFavorite) {
      const updated = favorites.filter(id => id !== product.id);
      localStorage.setItem('favorites', JSON.stringify(updated));
    } else {
      favorites.push(product.id);
      localStorage.setItem('favorites', JSON.stringify(favorites));
    }
    setIsFavorite(!isFavorite);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -4 }}
      className="group relative"
    >
      <div
        className="rounded-xl overflow-hidden backdrop-blur-sm border transition-all duration-300 cursor-pointer"
        style={{
          background: `linear-gradient(135deg, ${catInfo.color}08, ${catInfo.color}04)`,
          borderColor: expanded ? catInfo.color : `${catInfo.color}30`,
          boxShadow: expanded ? `0 0 30px ${catInfo.glow}` : `0 0 15px ${catInfo.glow}`,
        }}
        onClick={() => setExpanded(!expanded)}
      >
        {/* Hero Illustration */}
        {speciesImage && (
          <div className="relative h-40 overflow-hidden bg-gradient-to-b from-white/10 to-transparent flex items-center justify-center">
            <img
              src={speciesImage}
              alt={product.species[0]}
              className="h-full w-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-300"
            />
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background: `linear-gradient(135deg, transparent 0%, ${catInfo.color}15 100%)`,
              }}
            />
          </div>
        )}

        {/* Content */}
        <div className="p-6">
          {/* Header */}
          <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">{catInfo.emoji}</span>
              <span
               className="text-xs font-orbitron font-bold px-3 py-1 rounded-full text-white"
               style={{ backgroundColor: catInfo.color }}
              >
               {getCategoryLabel(product.category, lang)}
              </span>
            </div>
            <h3 className="font-orbitron text-lg font-bold text-foreground">
             {getProductName(product.name, lang)}
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleFavorite}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <Heart
                className="w-5 h-5 transition-all"
                fill={isFavorite ? '#ec4899' : 'none'}
                stroke={isFavorite ? '#ec4899' : 'currentColor'}
              />
            </motion.button>
            <motion.div
              animate={{ rotate: expanded ? 180 : 0 }}
              transition={{ duration: 0.3 }}
            >
              <ChevronDown className="w-5 h-5 text-primary" />
            </motion.div>
          </div>
        </div>

        {/* Description - Dynamic multilingual */}
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
          {getProductDescription(product.name, lang) || (lang === 'EN' ? product.description : getProductDescription(product.name, lang))}
        </p>

        {/* Species Badges */}
        <div className="flex flex-wrap gap-2 mb-4">
          {product.species?.slice(0, 4).map((sp) => (
            <span
              key={sp}
              className="text-xs font-orbitron px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-white"
            >
              {SPECIES_EMOJI[sp]} {getSpeciesLabel(sp, lang)}
            </span>
          ))}
          {product.species?.length > 4 && (
            <span className="text-xs font-orbitron px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-muted-foreground">
              +{product.species.length - 4} {lang === 'EN' ? 'more' : lang === 'AZ' ? 'daha' : 'еще'}
            </span>
          )}
        </div>

        {/* Expanded Content */}
        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="mt-4 pt-4 border-t border-white/10 space-y-4"
          >
            {/* Health Illustration for specific categories */}
            {(product.category?.includes('Anti-parasitic') || product.category?.includes('Antibiotics')) && (
              <div className="flex justify-center py-2">
                <img
                  src={product.category?.includes('Anti-parasitic') ? HEALTH_ILLUSTRATIONS.parasites : HEALTH_ILLUSTRATIONS.bacteria}
                  alt="Health illustration"
                  className="h-24 w-24 object-cover opacity-60 rounded-lg"
                />
              </div>
            )}
            {/* Dosage Form */}
            {product.dosage_form && (
              <div>
                <p className="text-xs font-orbitron text-primary mb-2 font-bold">{t.product_detail.dosage}</p>
                <p className="text-sm text-foreground">{product.dosage_form}</p>
              </div>
            )}

            {/* Features */}
            {product.features?.length > 0 && (
              <div>
                <p className="text-xs font-orbitron text-primary mb-2 font-bold">{t.product_expanded.features}</p>
                <ul className="space-y-1">
                  {product.features.map((f, i) => (
                    <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                      <Zap className="w-3 h-3 text-primary mt-0.5 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Efficacy */}
            {product.efficacy_rate && (
              <div>
                <p className="text-xs font-orbitron text-primary mb-2 font-bold">{t.product_detail.efficacy}</p>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-white/10 rounded-full h-2 overflow-hidden">
                    <div
                      className="h-full transition-all"
                      style={{ width: `${product.efficacy_rate}%`, backgroundColor: catInfo.color }}
                    />
                  </div>
                  <span className="text-sm font-bold text-foreground">{product.efficacy_rate}%</span>
                </div>
              </div>
            )}

            {/* All Species */}
            {product.species?.length > 4 && (
              <div>
                <p className="text-xs font-orbitron text-primary mb-2 font-bold">{t.product_expanded.allSpecies}</p>
                <div className="flex flex-wrap gap-2">
                  {product.species.map((sp) => (
                    <span key={sp} className="text-xs px-2 py-1 rounded bg-white/5 text-gray-300">
                      {SPECIES_EMOJI[sp]} {getSpeciesLabel(sp, lang)}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Price */}
            {product.price && (
              <div className="pt-2 border-t border-white/10">
                <p className="text-xs font-orbitron text-muted-foreground mb-1">{t.compare_page.price}</p>
                <p className="text-xl font-bold text-primary">${product.price.toFixed(2)}</p>
              </div>
            )}
          </motion.div>
        )}
        </div>
      </div>
    </motion.div>
  );
}