import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, Zap } from 'lucide-react';
import { useLang } from '@/lib/i18n';

export default function PredictiveSearchBar({ products, onSelect, placeholder, value, onChange }) {
  const { lang } = useLang();
  const [isOpen, setIsOpen] = useState(false);

  const suggestions = useMemo(() => {
    if (!value || value.length < 2) return [];
    
    const query = value.toLowerCase();
    const matches = products.filter(p =>
      p.name?.toLowerCase().includes(query) ||
      p.brand?.toLowerCase().includes(query) ||
      p.category?.toLowerCase().includes(query) ||
      p.tags?.some(tag => tag.toLowerCase().includes(query))
    );

    return matches.slice(0, 8).map(p => ({
      id: p.id,
      name: p.name,
      brand: p.brand,
      category: p.category,
      matchType: p.name?.toLowerCase().includes(query) ? 'name' : 
                 p.brand?.toLowerCase().includes(query) ? 'brand' : 
                 p.category?.toLowerCase().includes(query) ? 'category' : 'tag'
    }));
  }, [value, products]);

  const handleSelect = (product) => {
    onSelect(product);
    setIsOpen(false);
    onChange({ target: { value: product.name } });
  };

  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-4 top-3.5 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          placeholder={placeholder}
          value={value}
          onChange={(e) => {
            onChange(e);
            setIsOpen(e.target.value.length >= 2);
          }}
          onFocus={() => value.length >= 2 && setIsOpen(true)}
          onBlur={() => setTimeout(() => setIsOpen(false), 200)}
          className="w-full pl-12 pr-10 py-3 rounded-xl bg-card border border-primary/20 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary/60 focus:ring-2 focus:ring-primary/20 transition-all"
        />
        {value && (
          <button
            onClick={() => { onChange({ target: { value: '' } }); setIsOpen(false); }}
            className="absolute right-3 top-3.5 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      <AnimatePresence>
        {isOpen && suggestions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute top-full left-0 right-0 mt-2 bg-card border border-primary/20 rounded-xl shadow-lg overflow-hidden z-50"
            style={{
              boxShadow: '0 0 40px hsl(174 100% 54% / 0.15)',
              backdropFilter: 'blur(10px)',
            }}
          >
            <div className="max-h-96 overflow-y-auto">
              {suggestions.map((suggestion, idx) => (
                <motion.button
                  key={suggestion.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  onClick={() => handleSelect(suggestion)}
                  className="w-full px-4 py-3 flex items-start gap-3 hover:bg-primary/10 transition-colors border-b border-primary/5 last:border-0"
                >
                  <div className="flex-1 text-left">
                    <div className="font-semibold text-foreground text-sm">{suggestion.name}</div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-muted-foreground">{suggestion.brand}</span>
                      <span className="text-xs px-2 py-0.5 rounded bg-primary/10 text-primary font-mono">
                        {suggestion.category}
                      </span>
                      <span className="text-xs text-muted-foreground/60 capitalize">
                        {suggestion.matchType}
                      </span>
                    </div>
                  </div>
                  <Zap className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {isOpen && suggestions.length === 0 && value.length >= 2 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-0 right-0 mt-2 bg-card border border-primary/20 rounded-xl p-4 text-center text-sm text-muted-foreground"
        >
          {lang === 'EN' ? 'No products found' : lang === 'AZ' ? 'Məhsul tapılmadı' : 'Продукты не найдены'}
        </motion.div>
      )}
    </div>
  );
}