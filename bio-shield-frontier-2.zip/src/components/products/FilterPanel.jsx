import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useLang } from '@/lib/i18n';
import { getSpeciesLabel, SPECIES_EMOJI } from '@/lib/speciesTranslationsI18n';

export default function FilterPanel({ filters, setFilters, categories, species }) {
   const { lang, t } = useLang();
   const activeFilterCount = [
     filters.category,
     filters.species.length > 0,
     filters.dosageForm,
     filters.search
   ].filter(Boolean).length;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="space-y-6"
    >
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="font-orbitron text-lg font-bold text-foreground">{t.catalog_page.filters}</h3>
          {activeFilterCount > 0 && (
            <button
              onClick={() => setFilters({ category: '', species: [], dosageForm: '', search: '' })}
              className="text-xs font-orbitron text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
            >
              <X className="w-3 h-3" /> {t.catalog_page.clearAll}
            </button>
          )}
        </div>
        {activeFilterCount > 0 && (
          <p className="text-xs text-muted-foreground">
            {activeFilterCount} {activeFilterCount === 1 ? t.catalog_page.activeFilter : t.catalog_page.activeFilters}
          </p>
        )}
      </div>

      {/* Category Filter */}
      <div className="space-y-3">
        <label className="text-sm font-orbitron font-bold text-foreground block">{t.catalog_page.category}</label>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {categories.map((cat) => (
            <motion.button
              key={cat.id}
              whileHover={{ x: 4 }}
              onClick={() => setFilters({
                ...filters,
                category: filters.category === cat.id ? '' : cat.id
              })}
              className={`w-full text-left px-3 py-2 rounded-lg transition-all text-sm ${
                filters.category === cat.id
                  ? 'bg-white/10 border-l-2 font-semibold'
                  : 'hover:bg-white/5'
              }`}
              style={filters.category === cat.id ? { borderLeftColor: cat.color } : {}}
            >
              {cat.label}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Species Filter */}
      <div className="space-y-3">
        <label className="text-sm font-orbitron font-bold text-foreground block">{t.catalog_page.speciesFilter}</label>
        <div className="grid grid-cols-2 gap-2">
          {species.map((sp) => (
            <motion.button
              key={sp.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setFilters({
                ...filters,
                species: filters.species.includes(sp.id)
                  ? filters.species.filter(s => s !== sp.id)
                  : [...filters.species, sp.id]
              })}
              className={`px-3 py-2 rounded-lg transition-all text-xs font-orbitron font-bold text-center ${
                filters.species.includes(sp.id)
                  ? 'bg-primary/30 border border-primary/50 text-primary'
                  : 'bg-white/5 border border-white/10 text-foreground hover:bg-white/10'
              }`}
            >
              {SPECIES_EMOJI[sp.id] || sp.icon} {getSpeciesLabel(sp.id, lang)}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Active Species Tags */}
      {filters.species.length > 0 && (
        <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
          <p className="text-xs font-orbitron text-muted-foreground mb-2">{t.catalog_page.selectedSpecies}</p>
          <div className="flex flex-wrap gap-2">
            {filters.species.map((sp) => (
                <div
                  key={sp}
                  className="flex items-center gap-1 px-2 py-1 bg-primary/20 rounded text-xs"
                >
                  <span>{SPECIES_EMOJI[sp]}</span>
                  <span className="text-foreground">{getSpeciesLabel(sp, lang)}</span>
                  <button
                    onClick={() => setFilters({
                      ...filters,
                      species: filters.species.filter(x => x !== sp)
                    })}
                    className="ml-1 text-muted-foreground hover:text-primary transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
                ))}
                </div>
        </div>
      )}
    </motion.div>
  );
}